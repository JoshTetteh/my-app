import { NavigationContainer } from "@react-navigation/native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createStackNavigator } from "@react-navigation/stack"
import { SafeAreaProvider } from "react-native-safe-area-context"
import { StatusBar } from "expo-status-bar"
import { ThemeProvider } from "./src/context/ThemeContext"

// Screens
import HomeScreen from "./src/screens/HomeScreen"
import TherapistsScreen from "./src/screens/TherapistsScreen"
import ResourcesScreen from "./src/screens/ResourcesScreen"
import ProfileScreen from "./src/screens/ProfileScreen"
import AssessmentScreen from "./src/screens/AssessmentScreen"
import LoginScreen from "./src/screens/LoginScreen"
import SignupScreen from "./src/screens/SignupScreen"
import TherapistDetailScreen from "./src/screens/TherapistDetailScreen"
import BookingScreen from "./src/screens/BookingScreen"
import ResourceDetailScreen from "./src/screens/ResourceDetailScreen"
import AboutScreen from "./src/screens/AboutScreen"

// Icons
import { Ionicons } from "@expo/vector-icons"
import { FontAwesome5 } from "@expo/vector-icons"

const Tab = createBottomTabNavigator()
const Stack = createStackNavigator()

function HomeTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          if (route.name === "Home") {
            return <Ionicons name="home" size={size} color={color} />
          } else if (route.name === "Therapists") {
            return <FontAwesome5 name="user-md" size={size} color={color} />
          } else if (route.name === "Resources") {
            return <Ionicons name="book" size={size} color={color} />
          } else if (route.name === "Profile") {
            return <Ionicons name="person" size={size} color={color} />
          }
        },
        tabBarActiveTintColor: "#0d9488",
        tabBarInactiveTintColor: "gray",
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Therapists" component={TherapistsScreen} />
      <Tab.Screen name="Resources" component={ResourcesScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  )
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <NavigationContainer>
          <StatusBar style="auto" />
          <Stack.Navigator
            initialRouteName="HomeTabs"
            screenOptions={{
              headerStyle: {
                backgroundColor: "#0d9488",
              },
              headerTintColor: "#fff",
              headerTitleStyle: {
                fontWeight: "bold",
              },
            }}
          >
            <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ headerShown: false }} />
            <Stack.Screen
              name="Assessment"
              component={AssessmentScreen}
              options={{ title: "Mental Health Assessment" }}
            />
            <Stack.Screen name="Login" component={LoginScreen} options={{ title: "Log In" }} />
            <Stack.Screen name="Signup" component={SignupScreen} options={{ title: "Sign Up" }} />
            <Stack.Screen
              name="TherapistDetail"
              component={TherapistDetailScreen}
              options={{ title: "Therapist Profile" }}
            />
            <Stack.Screen name="Booking" component={BookingScreen} options={{ title: "Book Appointment" }} />
            <Stack.Screen name="ResourceDetail" component={ResourceDetailScreen} options={{ title: "Resource" }} />
            <Stack.Screen name="About" component={AboutScreen} options={{ title: "About Us" }} />
          </Stack.Navigator>
        </NavigationContainer>
      </ThemeProvider>
    </SafeAreaProvider>
  )
}

