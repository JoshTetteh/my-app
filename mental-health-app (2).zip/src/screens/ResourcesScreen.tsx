"use client"

import { useState } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image, FlatList } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"
import TabView from "../components/TabView"

export default function ResourcesScreen() {
  const navigation = useNavigation()
  const { colors } = useTheme()
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("articles")

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 24,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 12,
    },
    searchContainer: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.card,
      borderRadius: 8,
      paddingHorizontal: 12,
      marginBottom: 16,
    },
    searchInput: {
      flex: 1,
      paddingVertical: 12,
      paddingHorizontal: 8,
      color: colors.text,
    },
    section: {
      padding: 16,
    },
    sectionTitle: {
      fontSize: 20,
      fontWeight: "bold",
      marginBottom: 16,
      color: colors.text,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: 12,
      marginBottom: 16,
      overflow: "hidden",
    },
    cardImage: {
      width: "100%",
      height: 150,
    },
    cardContent: {
      padding: 16,
    },
    cardTitle: {
      fontSize: 18,
      fontWeight: "bold",
      marginBottom: 8,
      color: colors.text,
    },
    cardDescription: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 12,
    },
    cardMeta: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: 12,
    },
    badge: {
      backgroundColor: "#e6fffa", // teal-50
      paddingVertical: 4,
      paddingHorizontal: 8,
      borderRadius: 4,
      marginRight: 8,
    },
    badgeText: {
      color: colors.primary,
      fontSize: 12,
      fontWeight: "500",
    },
    readTime: {
      flexDirection: "row",
      alignItems: "center",
    },
    readTimeText: {
      color: "#6b7280", // gray-500
      fontSize: 12,
      marginLeft: 4,
    },
    button: {
      backgroundColor: "transparent",
      borderWidth: 1,
      borderColor: colors.primary,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
    },
    buttonText: {
      color: colors.primary,
      fontWeight: "500",
      marginRight: 4,
    },
    tabContent: {
      paddingTop: 16,
    },
    podcastCard: {
      flexDirection: "row",
      backgroundColor: colors.card,
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
    },
    podcastIcon: {
      width: 60,
      height: 60,
      borderRadius: 8,
      backgroundColor: "#e6fffa",
      alignItems: "center",
      justifyContent: "center",
      marginRight: 16,
    },
    podcastInfo: {
      flex: 1,
    },
    podcastTitle: {
      fontSize: 16,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 4,
    },
    podcastEpisode: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 8,
    },
    podcastDescription: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 8,
    },
    podcastDuration: {
      flexDirection: "row",
      alignItems: "center",
    },
    podcastDurationText: {
      color: "#6b7280", // gray-500
      fontSize: 12,
      marginLeft: 4,
    },
    toolsSection: {
      padding: 16,
    },
    toolsTitle: {
      fontSize: 20,
      fontWeight: "bold",
      marginBottom: 16,
      color: colors.text,
      textAlign: "center",
    },
    toolsDescription: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 16,
      textAlign: "center",
    },
    toolsGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
    },
    toolCard: {
      width: "48%",
      backgroundColor: colors.card,
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
      alignItems: "center",
    },
    toolIcon: {
      backgroundColor: "#e6fffa",
      width: 50,
      height: 50,
      borderRadius: 25,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 12,
    },
    toolTitle: {
      fontSize: 16,
      fontWeight: "bold",
      marginBottom: 8,
      textAlign: "center",
      color: colors.text,
    },
    toolDescription: {
      fontSize: 14,
      textAlign: "center",
      color: "#6b7280", // gray-500
      marginBottom: 12,
    },
    crisisSection: {
      padding: 16,
      backgroundColor: "#f9fafb", // gray-50
    },
    crisisTitle: {
      fontSize: 20,
      fontWeight: "bold",
      marginBottom: 8,
      color: colors.text,
      textAlign: "center",
    },
    crisisDescription: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 16,
      textAlign: "center",
    },
    crisisCard: {
      backgroundColor: "#e6fffa", // teal-50
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
      borderWidth: 1,
      borderColor: "#99f6e4", // teal-200
    },
    crisisCardTitle: {
      fontSize: 16,
      fontWeight: "bold",
      color: colors.primary,
      marginBottom: 8,
      flexDirection: "row",
      alignItems: "center",
    },
    crisisCardDescription: {
      fontSize: 14,
      color: "#4b5563", // gray-600
      marginBottom: 8,
    },
    crisisNumber: {
      fontSize: 18,
      fontWeight: "bold",
      color: colors.primary,
      marginBottom: 12,
    },
  })

  const renderArticleItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("ResourceDetail" as never, { resource: item, type: "article" } as never)}
    >
      <View style={styles.cardContent}>
        <View style={styles.cardMeta}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.category}</Text>
          </View>
          <View style={styles.readTime}>
            <Ionicons name="time-outline" size={12} color="#6b7280" />
            <Text style={styles.readTimeText}>{item.readTime} min read</Text>
          </View>
        </View>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardDescription}>{item.description}</Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Read Full Article</Text>
          <Ionicons name="arrow-forward" size={16} color={colors.primary} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )

  const renderGuideItem = ({ item }) => (
    <TouchableOpacity
      style={[styles.card, { flexDirection: "row" }]}
      onPress={() => navigation.navigate("ResourceDetail" as never, { resource: item, type: "guide" } as never)}
    >
      <Image source={{ uri: "https://via.placeholder.com/150" }} style={{ width: 100, height: "100%" }} />
      <View style={styles.cardContent}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{item.category}</Text>
        </View>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardDescription}>{item.description}</Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Download Guide</Text>
          <Ionicons name="download-outline" size={16} color={colors.primary} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )

  const renderVideoItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("ResourceDetail" as never, { resource: item, type: "video" } as never)}
    >
      <View style={{ position: "relative" }}>
        <Image source={{ uri: "https://via.placeholder.com/350x150" }} style={styles.cardImage} />
        <View
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              backgroundColor: "rgba(0,0,0,0.5)",
              borderRadius: 30,
              padding: 12,
            }}
          >
            <Ionicons name="play" size={24} color="#ffffff" />
          </View>
        </View>
      </View>
      <View style={styles.cardContent}>
        <View style={styles.cardMeta}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{item.category}</Text>
          </View>
          <View style={styles.readTime}>
            <Ionicons name="time-outline" size={12} color="#6b7280" />
            <Text style={styles.readTimeText}>{item.duration}</Text>
          </View>
        </View>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardDescription}>{item.description}</Text>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Watch Video</Text>
          <Ionicons name="arrow-forward" size={16} color={colors.primary} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  )

  const renderPodcastItem = ({ item }) => (
    <TouchableOpacity
      style={styles.podcastCard}
      onPress={() => navigation.navigate("ResourceDetail" as never, { resource: item, type: "podcast" } as never)}
    >
      <View style={styles.podcastIcon}>
        <Ionicons name="headset" size={24} color={colors.primary} />
      </View>
      <View style={styles.podcastInfo}>
        <Text style={styles.podcastTitle}>{item.title}</Text>
        <Text style={styles.podcastEpisode}>
          Episode {item.episode}: {item.episodeTitle}
        </Text>
        <Text style={styles.podcastDescription}>{item.description}</Text>
        <View style={styles.podcastDuration}>
          <Ionicons name="time-outline" size={12} color="#6b7280" />
          <Text style={styles.podcastDurationText}>{item.duration}</Text>
        </View>
      </View>
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Mental Health Resources</Text>
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={20} color="#6b7280" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search resources..."
              placeholderTextColor="#6b7280"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Resources</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <TouchableOpacity
              style={[styles.card, { width: 280, marginRight: 16 }]}
              onPress={() =>
                navigation.navigate(
                  "ResourceDetail" as never,
                  {
                    resource: articles[0],
                    type: "article",
                  } as never,
                )
              }
            >
              <Image source={{ uri: "https://via.placeholder.com/280x150" }} style={styles.cardImage} />
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>Understanding Anxiety</Text>
                <Text style={styles.cardDescription}>
                  Learn about the different types of anxiety disorders and effective coping strategies.
                </Text>
                <TouchableOpacity style={styles.button}>
                  <Text style={styles.buttonText}>Read More</Text>
                  <Ionicons name="arrow-forward" size={16} color={colors.primary} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.card, { width: 280, marginRight: 16 }]}
              onPress={() =>
                navigation.navigate(
                  "ResourceDetail" as never,
                  {
                    resource: articles[1],
                    type: "article",
                  } as never,
                )
              }
            >
              <Image source={{ uri: "https://via.placeholder.com/280x150" }} style={styles.cardImage} />
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>Depression: Signs and Support</Text>
                <Text style={styles.cardDescription}>
                  Recognize the symptoms of depression and discover ways to find support.
                </Text>
                <TouchableOpacity style={styles.button}>
                  <Text style={styles.buttonText}>Read More</Text>
                  <Ionicons name="arrow-forward" size={16} color={colors.primary} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.card, { width: 280 }]}
              onPress={() =>
                navigation.navigate(
                  "ResourceDetail" as never,
                  {
                    resource: articles[2],
                    type: "article",
                  } as never,
                )
              }
            >
              <Image source={{ uri: "https://via.placeholder.com/280x150" }} style={styles.cardImage} />
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>Mindfulness Techniques</Text>
                <Text style={styles.cardDescription}>
                  Simple mindfulness practices you can incorporate into your daily routine.
                </Text>
                <TouchableOpacity style={styles.button}>
                  <Text style={styles.buttonText}>Read More</Text>
                  <Ionicons name="arrow-forward" size={16} color={colors.primary} />
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </ScrollView>
        </View>

        <TabView
          tabs={[
            { key: "articles", title: "Articles", icon: "book-outline" },
            { key: "guides", title: "Guides", icon: "document-text-outline" },
            { key: "videos", title: "Videos", icon: "videocam-outline" },
            { key: "podcasts", title: "Podcasts", icon: "headset-outline" },
          ]}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        >
          {activeTab === "articles" && (
            <View style={styles.tabContent}>
              <FlatList
                data={articles}
                renderItem={renderArticleItem}
                keyExtractor={(item) => item.title}
                scrollEnabled={false}
              />
              <TouchableOpacity style={{ alignSelf: "center", marginTop: 8 }} onPress={() => {}}>
                <Text style={{ color: colors.primary, fontWeight: "500" }}>View All Articles</Text>
              </TouchableOpacity>
            </View>
          )}

          {activeTab === "guides" && (
            <View style={styles.tabContent}>
              <FlatList
                data={guides}
                renderItem={renderGuideItem}
                keyExtractor={(item) => item.title}
                scrollEnabled={false}
              />
              <TouchableOpacity style={{ alignSelf: "center", marginTop: 8 }} onPress={() => {}}>
                <Text style={{ color: colors.primary, fontWeight: "500" }}>View All Guides</Text>
              </TouchableOpacity>
            </View>
          )}

          {activeTab === "videos" && (
            <View style={styles.tabContent}>
              <FlatList
                data={videos}
                renderItem={renderVideoItem}
                keyExtractor={(item) => item.title}
                scrollEnabled={false}
              />
              <TouchableOpacity style={{ alignSelf: "center", marginTop: 8 }} onPress={() => {}}>
                <Text style={{ color: colors.primary, fontWeight: "500" }}>View All Videos</Text>
              </TouchableOpacity>
            </View>
          )}

          {activeTab === "podcasts" && (
            <View style={styles.tabContent}>
              <FlatList
                data={podcasts}
                renderItem={renderPodcastItem}
                keyExtractor={(item) => item.title}
                scrollEnabled={false}
              />
              <TouchableOpacity style={{ alignSelf: "center", marginTop: 8 }} onPress={() => {}}>
                <Text style={{ color: colors.primary, fontWeight: "500" }}>View All Podcasts</Text>
              </TouchableOpacity>
            </View>
          )}
        </TabView>

        <View style={styles.toolsSection}>
          <Text style={styles.toolsTitle}>Self-Help Tools</Text>
          <Text style={styles.toolsDescription}>
            Practical tools and exercises to support your mental wellbeing between therapy sessions.
          </Text>
          <View style={styles.toolsGrid}>
            <TouchableOpacity style={styles.toolCard}>
              <View style={styles.toolIcon}>
                <Ionicons name="brain" size={24} color={colors.primary} />
              </View>
              <Text style={styles.toolTitle}>Mood Tracker</Text>
              <Text style={styles.toolDescription}>Track your daily mood patterns</Text>
              <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>Try It</Text>
              </TouchableOpacity>
            </TouchableOpacity>

            <TouchableOpacity style={styles.toolCard}>
              <View style={styles.toolIcon}>
                <Ionicons name="sparkles" size={24} color={colors.primary} />
              </View>
              <Text style={styles.toolTitle}>Guided Meditation</Text>
              <Text style={styles.toolDescription}>Audio-guided meditations</Text>
              <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>Try It</Text>
              </TouchableOpacity>
            </TouchableOpacity>

            <TouchableOpacity style={styles.toolCard}>
              <View style={styles.toolIcon}>
                <Ionicons name="document-text" size={24} color={colors.primary} />
              </View>
              <Text style={styles.toolTitle}>Thought Journal</Text>
              <Text style={styles.toolDescription}>Record and challenge thoughts</Text>
              <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>Try It</Text>
              </TouchableOpacity>
            </TouchableOpacity>

            <TouchableOpacity style={styles.toolCard}>
              <View style={styles.toolIcon}>
                <Ionicons name="moon" size={24} color={colors.primary} />
              </View>
              <Text style={styles.toolTitle}>Sleep Diary</Text>
              <Text style={styles.toolDescription}>Monitor sleep patterns</Text>
              <TouchableOpacity style={styles.button}>
                <Text style={styles.buttonText}>Try It</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.crisisSection}>
          <Text style={styles.crisisTitle}>Crisis Support</Text>
          <Text style={styles.crisisDescription}>
            If you're experiencing a mental health crisis, please reach out to these resources for immediate support.
          </Text>

          <View style={styles.crisisCard}>
            <Text style={styles.crisisCardTitle}>
              <Ionicons name="call" size={16} color={colors.primary} style={{ marginRight: 8 }} />
              National Suicide Prevention Lifeline
            </Text>
            <Text style={styles.crisisCardDescription}>
              24/7, free and confidential support for people in distress.
            </Text>
            <Text style={styles.crisisNumber}>1-800-273-8255</Text>
            <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]}>
              <Text style={[styles.buttonText, { color: "#ffffff" }]}>Visit Website</Text>
              <Ionicons name="open" size={16} color="#ffffff" style={{ marginLeft: 4 }} />
            </TouchableOpacity>
          </View>

          <View style={styles.crisisCard}>
            <Text style={styles.crisisCardTitle}>
              <Ionicons name="chatbubble" size={16} color={colors.primary} style={{ marginRight: 8 }} />
              Crisis Text Line
            </Text>
            <Text style={styles.crisisCardDescription}>Text-based crisis intervention service available 24/7.</Text>
            <Text style={styles.crisisNumber}>Text HOME to 741741</Text>
            <TouchableOpacity style={[styles.button, { backgroundColor: colors.primary }]}>
              <Text style={[styles.buttonText, { color: "#ffffff" }]}>Visit Website</Text>
              <Ionicons name="open" size={16} color="#ffffff" style={{ marginLeft: 4 }} />
            </TouchableOpacity>
          </View>

          <View
            style={{
              backgroundColor: "#ffffff",
              borderRadius: 8,
              padding: 12,
              marginTop: 16,
            }}
          >
            <Text style={{ textAlign: "center", color: "#4b5563" }}>
              <Text style={{ fontWeight: "bold" }}>Note:</Text> If you or someone you know is in immediate danger,
              please call emergency services (911 in the US) or go to your nearest emergency room.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

// Sample data for the resources
const articles = [
  {
    title: "Understanding the Link Between Sleep and Mental Health",
    description: "How sleep affects your mental wellbeing",
    excerpt:
      "Sleep and mental health are closely connected. Poor sleep can contribute to the development of mental health issues, while mental health conditions can make it harder to sleep well...",
    category: "Sleep",
    readTime: 5,
    link: "/resources/articles/sleep-mental-health",
  },
  {
    title: "Recognizing Signs of Burnout",
    description: "How to identify and address burnout before it becomes severe",
    excerpt:
      "Burnout is a state of chronic stress that leads to physical and emotional exhaustion, cynicism, detachment, and feelings of ineffectiveness. Learn to recognize the early warning signs...",
    category: "Stress Management",
    readTime: 7,
    link: "/resources/articles/burnout-signs",
  },
  {
    title: "Supporting a Loved One with Depression",
    description: "Practical ways to help someone experiencing depression",
    excerpt:
      "When someone you care about is depressed, it can be difficult to know how to help. This guide provides practical strategies for offering support while taking care of your own wellbeing...",
    category: "Depression",
    readTime: 8,
    link: "/resources/articles/supporting-depression",
  },
  {
    title: "The Benefits of Cognitive Behavioral Therapy",
    description: "How CBT works and what to expect",
    excerpt:
      "Cognitive Behavioral Therapy (CBT) is one of the most effective forms of psychotherapy. It focuses on identifying negative thought patterns and developing healthier alternatives...",
    category: "Therapy",
    readTime: 6,
    link: "/resources/articles/cbt-benefits",
  },
]

const guides = [
  {
    title: "Complete Guide to Anxiety Management",
    description: "A comprehensive resource for understanding and managing anxiety disorders",
    category: "Anxiety",
    link: "/resources/guides/anxiety-management",
  },
  {
    title: "Mindfulness for Beginners",
    description: "Simple techniques to incorporate mindfulness into your daily routine",
    category: "Mindfulness",
    link: "/resources/guides/mindfulness-beginners",
  },
  {
    title: "Navigating Grief and Loss",
    description: "Understanding the grief process and healthy coping strategies",
    category: "Grief",
    link: "/resources/guides/grief-loss",
  },
]

const videos = [
  {
    title: "5-Minute Anxiety Relief Exercise",
    description: "A quick breathing technique to calm anxiety in the moment",
    category: "Anxiety",
    duration: "5:23",
    link: "/resources/videos/anxiety-relief",
  },
  {
    title: "Understanding Trauma Responses",
    description: "How trauma affects the brain and body",
    category: "Trauma",
    duration: "12:47",
    link: "/resources/videos/trauma-responses",
  },
]

const podcasts = [
  {
    title: "Mental Health Matters",
    episode: "42",
    episodeTitle: "Breaking the Stigma Around Therapy",
    description: "A discussion about why seeking therapy is a sign of strength, not weakness",
    duration: "38 min",
    link: "/resources/podcasts/mental-health-matters-42",
  },
  {
    title: "The Mindful Minute",
    episode: "15",
    episodeTitle: "Practicing Self-Compassion",
    description: "Learn how to be kinder to yourself during difficult times",
    duration: "22 min",
    link: "/resources/podcasts/mindful-minute-15",
  },
]

