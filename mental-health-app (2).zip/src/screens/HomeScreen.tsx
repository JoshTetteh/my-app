"use client"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, useWindowDimensions } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons, FontAwesome5 } from "@expo/vector-icons"
import Card from "../components/Card"

export default function HomeScreen() {
  const navigation = useNavigation()
  const { colors } = useTheme()
  const { width } = useWindowDimensions()

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    logo: {
      flexDirection: "row",
      alignItems: "center",
    },
    logoText: {
      fontSize: 20,
      fontWeight: "bold",
      marginLeft: 8,
      color: colors.text,
    },
    hero: {
      padding: 20,
      backgroundColor: "#e6fffa", // teal-50
    },
    heroTitle: {
      fontSize: 28,
      fontWeight: "bold",
      color: "#000000",
      marginBottom: 10,
    },
    heroText: {
      fontSize: 16,
      color: "#4b5563", // gray-600
      marginBottom: 20,
    },
    buttonRow: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
    },
    primaryButton: {
      backgroundColor: colors.primary,
      paddingVertical: 12,
      paddingHorizontal: 20,
      borderRadius: 8,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 10,
      flex: 1,
      marginRight: 8,
    },
    secondaryButton: {
      backgroundColor: "transparent",
      paddingVertical: 12,
      paddingHorizontal: 20,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.primary,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 10,
      flex: 1,
    },
    buttonText: {
      color: "#ffffff",
      fontWeight: "bold",
      marginLeft: 8,
    },
    secondaryButtonText: {
      color: colors.primary,
      fontWeight: "bold",
      marginLeft: 8,
    },
    section: {
      padding: 20,
    },
    sectionTitle: {
      fontSize: 22,
      fontWeight: "bold",
      marginBottom: 16,
      color: colors.text,
    },
    featuresGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
    },
    featureCard: {
      width: width > 600 ? "30%" : "48%",
      backgroundColor: colors.card,
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
      alignItems: "center",
    },
    featureIcon: {
      backgroundColor: "#e6fffa",
      width: 60,
      height: 60,
      borderRadius: 30,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 12,
    },
    featureTitle: {
      fontSize: 16,
      fontWeight: "bold",
      marginBottom: 8,
      textAlign: "center",
      color: colors.text,
    },
    featureText: {
      fontSize: 14,
      textAlign: "center",
      color: "#6b7280", // gray-500
    },
    ctaSection: {
      padding: 20,
      backgroundColor: colors.primary,
      alignItems: "center",
      marginTop: 20,
    },
    ctaTitle: {
      fontSize: 22,
      fontWeight: "bold",
      color: "#ffffff",
      marginBottom: 12,
      textAlign: "center",
    },
    ctaText: {
      fontSize: 16,
      color: "#ffffff",
      marginBottom: 20,
      textAlign: "center",
    },
    ctaButton: {
      backgroundColor: "#ffffff",
      paddingVertical: 12,
      paddingHorizontal: 24,
      borderRadius: 8,
    },
    ctaButtonText: {
      color: colors.primary,
      fontWeight: "bold",
      fontSize: 16,
    },
  })

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.logo}>
          <Ionicons name="heart" size={24} color={colors.primary} />
          <Text style={styles.logoText}>MindfulCare</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate("Login" as never)}>
          <Ionicons name="person-circle-outline" size={28} color={colors.text} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <Text style={styles.heroTitle}>Mental Health Support When You Need It Most</Text>
          <Text style={styles.heroText}>
            Connect with licensed therapists for virtual or in-person sessions. Take our assessment to find the right
            care for your needs.
          </Text>
          <View style={styles.buttonRow}>
            <TouchableOpacity style={styles.primaryButton} onPress={() => navigation.navigate("Assessment" as never)}>
              <FontAwesome5 name="clipboard-check" size={16} color="#ffffff" />
              <Text style={styles.buttonText}>Take Assessment</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton} onPress={() => navigation.navigate("Therapists" as never)}>
              <FontAwesome5 name="user-md" size={16} color={colors.primary} />
              <Text style={styles.secondaryButtonText}>Find Therapists</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
            <Card style={{ width: "30%", alignItems: "center" }}>
              <View style={styles.featureIcon}>
                <FontAwesome5 name="clipboard-check" size={24} color={colors.primary} />
              </View>
              <Text style={[styles.featureTitle, { fontSize: 14 }]}>Complete Assessment</Text>
            </Card>
            <Card style={{ width: "30%", alignItems: "center" }}>
              <View style={styles.featureIcon}>
                <FontAwesome5 name="user-md" size={24} color={colors.primary} />
              </View>
              <Text style={[styles.featureTitle, { fontSize: 14 }]}>Find Therapist</Text>
            </Card>
            <Card style={{ width: "30%", alignItems: "center" }}>
              <View style={styles.featureIcon}>
                <Ionicons name="calendar" size={24} color={colors.primary} />
              </View>
              <Text style={[styles.featureTitle, { fontSize: 14 }]}>Book Appointment</Text>
            </Card>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Features</Text>
          <View style={styles.featuresGrid}>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="videocam" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureTitle}>Virtual Sessions</Text>
              <Text style={styles.featureText}>Connect from the comfort of your home</Text>
            </View>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="people" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureTitle}>Caregiver Support</Text>
              <Text style={styles.featureText}>Book for loved ones</Text>
            </View>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <FontAwesome5 name="clipboard-check" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureTitle}>Assessment</Text>
              <Text style={styles.featureText}>Find the right care</Text>
            </View>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Ionicons name="calendar" size={24} color={colors.primary} />
              </View>
              <Text style={styles.featureTitle}>Scheduling</Text>
              <Text style={styles.featureText}>Book at your convenience</Text>
            </View>
          </View>
        </View>

        <View style={styles.ctaSection}>
          <Text style={styles.ctaTitle}>Ready to Get Started?</Text>
          <Text style={styles.ctaText}>Take the first step toward better mental health today.</Text>
          <TouchableOpacity style={styles.ctaButton} onPress={() => navigation.navigate("Signup" as never)}>
            <Text style={styles.ctaButtonText}>Create an Account</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

