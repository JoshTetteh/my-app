"use client"

import { useState } from "react"
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from "react-native"
import { useNavigation } from "@react-navigation/native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"
import Card from "../components/Card"
import ProgressBar from "../components/ProgressBar"
import RadioButton from "../components/RadioButton"
import TextArea from "../components/TextArea"

export default function AssessmentScreen() {
  const navigation = useNavigation()
  const { colors } = useTheme()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState({})
  const [completed, setCompleted] = useState(false)

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    content: {
      padding: 16,
    },
    progressContainer: {
      marginBottom: 20,
    },
    questionNumber: {
      fontSize: 16,
      fontWeight: "500",
      marginBottom: 8,
      color: colors.text,
    },
    questionText: {
      fontSize: 18,
      fontWeight: "bold",
      marginBottom: 20,
      color: colors.text,
    },
    optionContainer: {
      marginBottom: 20,
    },
    buttonContainer: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginTop: 20,
    },
    button: {
      paddingVertical: 12,
      paddingHorizontal: 20,
      borderRadius: 8,
      flexDirection: "row",
      alignItems: "center",
    },
    primaryButton: {
      backgroundColor: colors.primary,
    },
    secondaryButton: {
      backgroundColor: "transparent",
      borderWidth: 1,
      borderColor: colors.primary,
    },
    buttonText: {
      fontWeight: "500",
      marginLeft: 8,
    },
    primaryButtonText: {
      color: "#ffffff",
    },
    secondaryButtonText: {
      color: colors.primary,
    },
    completedCard: {
      padding: 20,
      alignItems: "center",
    },
    completedTitle: {
      fontSize: 24,
      fontWeight: "bold",
      marginBottom: 12,
      color: colors.text,
    },
    completedDescription: {
      fontSize: 16,
      textAlign: "center",
      marginBottom: 20,
      color: "#6b7280", // gray-500
    },
    resultSection: {
      width: "100%",
      marginBottom: 20,
    },
    resultTitle: {
      fontSize: 18,
      fontWeight: "bold",
      marginBottom: 12,
      color: colors.text,
    },
    resultList: {
      backgroundColor: colors.card,
      borderRadius: 8,
      padding: 16,
    },
    resultItem: {
      flexDirection: "row",
      alignItems: "flex-start",
      marginBottom: 8,
    },
    resultBullet: {
      color: colors.primary,
      marginRight: 8,
      fontSize: 16,
    },
    resultText: {
      flex: 1,
      fontSize: 16,
      color: colors.text,
    },
    recommendationText: {
      fontSize: 16,
      marginBottom: 20,
      color: "#6b7280", // gray-500
    },
  })

  const questions = [
    {
      id: 1,
      question: "Over the past 2 weeks, how often have you felt down, depressed, or hopeless?",
      options: [
        { value: "0", label: "Not at all" },
        { value: "1", label: "Several days" },
        { value: "2", label: "More than half the days" },
        { value: "3", label: "Nearly every day" },
      ],
    },
    {
      id: 2,
      question: "Over the past 2 weeks, how often have you had little interest or pleasure in doing things?",
      options: [
        { value: "0", label: "Not at all" },
        { value: "1", label: "Several days" },
        { value: "2", label: "More than half the days" },
        { value: "3", label: "Nearly every day" },
      ],
    },
    {
      id: 3,
      question:
        "Over the past 2 weeks, how often have you had trouble falling or staying asleep, or sleeping too much?",
      options: [
        { value: "0", label: "Not at all" },
        { value: "1", label: "Several days" },
        { value: "2", label: "More than half the days" },
        { value: "3", label: "Nearly every day" },
      ],
    },
    {
      id: 4,
      question: "Over the past 2 weeks, how often have you felt tired or had little energy?",
      options: [
        { value: "0", label: "Not at all" },
        { value: "1", label: "Several days" },
        { value: "2", label: "More than half the days" },
        { value: "3", label: "Nearly every day" },
      ],
    },
    {
      id: 5,
      question: "Is there anything specific you'd like to discuss with a therapist?",
      textArea: true,
    },
    {
      id: 6,
      question: "Do you prefer in-person or virtual therapy sessions?",
      options: [
        { value: "in-person", label: "In-person sessions" },
        { value: "virtual", label: "Virtual sessions" },
        { value: "no-preference", label: "No preference" },
      ],
    },
  ]

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const handleAnswerChange = (value) => {
    setAnswers({
      ...answers,
      [questions[currentQuestion].id]: value,
    })
  }

  const progress = ((currentQuestion + 1) / questions.length) * 100

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.content}>
        {!completed ? (
          <Card>
            <View style={styles.progressContainer}>
              <Text style={styles.questionNumber}>
                Question {currentQuestion + 1} of {questions.length}
              </Text>
              <ProgressBar progress={progress} />
            </View>

            <Text style={styles.questionText}>{questions[currentQuestion].question}</Text>

            {questions[currentQuestion].textArea ? (
              <TextArea
                value={answers[questions[currentQuestion].id] || ""}
                onChangeText={handleAnswerChange}
                placeholder="Type your answer here..."
              />
            ) : (
              <View style={styles.optionContainer}>
                {questions[currentQuestion].options?.map((option) => (
                  <RadioButton
                    key={option.value}
                    label={option.label}
                    value={option.value}
                    selected={answers[questions[currentQuestion].id] === option.value}
                    onSelect={() => handleAnswerChange(option.value)}
                  />
                ))}
              </View>
            )}

            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.button, styles.secondaryButton]}
                onPress={handlePrevious}
                disabled={currentQuestion === 0}
              >
                <Ionicons name="arrow-back" size={16} color={colors.primary} />
                <Text style={[styles.buttonText, styles.secondaryButtonText]}>Previous</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.button, styles.primaryButton]}
                onPress={handleNext}
                disabled={!answers[questions[currentQuestion].id]}
              >
                <Text style={[styles.buttonText, styles.primaryButtonText]}>
                  {currentQuestion === questions.length - 1 ? "Complete" : "Next"}
                </Text>
                {currentQuestion !== questions.length - 1 && (
                  <Ionicons name="arrow-forward" size={16} color="#ffffff" />
                )}
              </TouchableOpacity>
            </View>
          </Card>
        ) : (
          <Card style={styles.completedCard}>
            <Text style={styles.completedTitle}>Assessment Complete</Text>
            <Text style={styles.completedDescription}>
              Thank you for completing the assessment. Based on your responses, we can now help you find the right
              therapist.
            </Text>

            <View style={styles.resultSection}>
              <Text style={styles.resultTitle}>
                Your responses indicate that you may benefit from speaking with a therapist who specializes in:
              </Text>
              <View style={styles.resultList}>
                <View style={styles.resultItem}>
                  <Text style={styles.resultBullet}>•</Text>
                  <Text style={styles.resultText}>Depression and mood disorders</Text>
                </View>
                <View style={styles.resultItem}>
                  <Text style={styles.resultBullet}>•</Text>
                  <Text style={styles.resultText}>Anxiety management</Text>
                </View>
                <View style={styles.resultItem}>
                  <Text style={styles.resultBullet}>•</Text>
                  <Text style={styles.resultText}>Sleep issues</Text>
                </View>
              </View>
            </View>

            <Text style={styles.recommendationText}>
              We recommend booking an appointment with a therapist to discuss your concerns and develop a personalized
              treatment plan.
            </Text>

            <View style={styles.buttonContainer}>
              <TouchableOpacity style={[styles.button, styles.secondaryButton]} onPress={() => setCompleted(false)}>
                <Text style={[styles.buttonText, styles.secondaryButtonText]}>Retake Assessment</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.button, styles.primaryButton]}
                onPress={() => navigation.navigate("Therapists" as never)}
              >
                <Text style={[styles.buttonText, styles.primaryButtonText]}>Find Therapists</Text>
              </TouchableOpacity>
            </View>
          </Card>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

