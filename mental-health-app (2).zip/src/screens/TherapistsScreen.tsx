"use client"

import { useState } from "react"
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, Image } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useNavigation } from "@react-navigation/native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"
import FilterModal from "../components/FilterModal"

export default function TherapistsScreen() {
  const navigation = useNavigation()
  const { colors } = useTheme()
  const [searchQuery, setSearchQuery] = useState("")
  const [filterModalVisible, setFilterModalVisible] = useState(false)
  const [filters, setFilters] = useState({
    sessionType: "all",
    specialty: "all",
    availability: [],
    insurance: [],
  })

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 24,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 12,
    },
    searchContainer: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.card,
      borderRadius: 8,
      paddingHorizontal: 12,
      marginBottom: 16,
    },
    searchInput: {
      flex: 1,
      paddingVertical: 12,
      paddingHorizontal: 8,
      color: colors.text,
    },
    filterRow: {
      flexDirection: "row",
      justifyContent: "space-between",
    },
    filterButton: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.card,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 12,
    },
    filterButtonText: {
      marginLeft: 4,
      color: colors.text,
    },
    therapistCard: {
      backgroundColor: colors.card,
      borderRadius: 12,
      marginBottom: 16,
      overflow: "hidden",
    },
    therapistCardContent: {
      padding: 16,
    },
    therapistHeader: {
      flexDirection: "row",
      marginBottom: 12,
    },
    therapistAvatar: {
      width: 70,
      height: 70,
      borderRadius: 35,
      marginRight: 12,
    },
    therapistInfo: {
      flex: 1,
      justifyContent: "center",
    },
    therapistName: {
      fontSize: 18,
      fontWeight: "bold",
      color: colors.text,
      marginBottom: 4,
    },
    therapistTitle: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginBottom: 4,
    },
    ratingContainer: {
      flexDirection: "row",
      alignItems: "center",
    },
    ratingText: {
      fontSize: 14,
      fontWeight: "500",
      marginLeft: 4,
      color: colors.text,
    },
    reviewCount: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginLeft: 4,
    },
    specialtiesContainer: {
      flexDirection: "row",
      flexWrap: "wrap",
      marginBottom: 12,
    },
    specialtyBadge: {
      backgroundColor: "#e6fffa", // teal-50
      paddingVertical: 4,
      paddingHorizontal: 8,
      borderRadius: 4,
      marginRight: 8,
      marginBottom: 8,
    },
    specialtyText: {
      color: colors.primary,
      fontSize: 12,
      fontWeight: "500",
    },
    locationContainer: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: 8,
    },
    locationText: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginLeft: 4,
    },
    sessionTypesContainer: {
      flexDirection: "row",
      marginBottom: 12,
    },
    sessionType: {
      flexDirection: "row",
      alignItems: "center",
      marginRight: 16,
    },
    sessionTypeText: {
      fontSize: 14,
      color: "#6b7280", // gray-500
      marginLeft: 4,
    },
    availabilityText: {
      fontSize: 14,
      fontWeight: "500",
      color: colors.primary,
      marginBottom: 12,
    },
    buttonsContainer: {
      flexDirection: "row",
      justifyContent: "space-between",
    },
    primaryButton: {
      backgroundColor: colors.primary,
      borderRadius: 8,
      paddingVertical: 10,
      paddingHorizontal: 16,
      flex: 1,
      marginRight: 8,
      alignItems: "center",
    },
    primaryButtonText: {
      color: "#ffffff",
      fontWeight: "500",
    },
    secondaryButton: {
      backgroundColor: "transparent",
      borderWidth: 1,
      borderColor: colors.primary,
      borderRadius: 8,
      paddingVertical: 10,
      paddingHorizontal: 16,
      flex: 1,
      alignItems: "center",
    },
    secondaryButtonText: {
      color: colors.primary,
      fontWeight: "500",
    },
  })

  const filteredTherapists = therapists.filter((therapist) => {
    // Filter by search term
    const matchesSearch =
      therapist.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      therapist.specialties.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))

    // Filter by session type
    const matchesSessionType =
      filters.sessionType === "all" ||
      (filters.sessionType === "virtual" && therapist.virtual) ||
      (filters.sessionType === "in-person" && therapist.inPerson)

    // Filter by specialty
    const matchesSpecialty =
      filters.specialty === "all" ||
      therapist.specialties.some((s) => s.toLowerCase() === filters.specialty.toLowerCase())

    return matchesSearch && matchesSessionType && matchesSpecialty
  })

  const renderTherapistItem = ({ item }) => (
    <TouchableOpacity
      style={styles.therapistCard}
      onPress={() => navigation.navigate("TherapistDetail" as never, { therapist: item } as never)}
    >
      <View style={styles.therapistCardContent}>
        <View style={styles.therapistHeader}>
          <Image source={{ uri: "https://via.placeholder.com/70" }} style={styles.therapistAvatar} />
          <View style={styles.therapistInfo}>
            <Text style={styles.therapistName}>{item.name}</Text>
            <Text style={styles.therapistTitle}>{item.title}</Text>
            <View style={styles.ratingContainer}>
              <Ionicons name="star" size={16} color="#FBBF24" />
              <Text style={styles.ratingText}>{item.rating}</Text>
              <Text style={styles.reviewCount}>({item.reviews} reviews)</Text>
            </View>
          </View>
        </View>

        <View style={styles.specialtiesContainer}>
          {item.specialties.map((specialty, index) => (
            <View key={index} style={styles.specialtyBadge}>
              <Text style={styles.specialtyText}>{specialty}</Text>
            </View>
          ))}
        </View>

        <View style={styles.locationContainer}>
          <Ionicons name="location" size={16} color="#6b7280" />
          <Text style={styles.locationText}>{item.location}</Text>
        </View>

        <View style={styles.sessionTypesContainer}>
          {item.virtual && (
            <View style={styles.sessionType}>
              <Ionicons name="videocam" size={16} color="#6b7280" />
              <Text style={styles.sessionTypeText}>Virtual</Text>
            </View>
          )}
          {item.inPerson && (
            <View style={styles.sessionType}>
              <Ionicons name="person" size={16} color="#6b7280" />
              <Text style={styles.sessionTypeText}>In-person</Text>
            </View>
          )}
        </View>

        <Text style={styles.availabilityText}>{item.availability}</Text>

        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={() => navigation.navigate("Booking" as never, { therapistId: item.id } as never)}
          >
            <Text style={styles.primaryButtonText}>Book Now</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={() => navigation.navigate("TherapistDetail" as never, { therapist: item } as never)}
          >
            <Text style={styles.secondaryButtonText}>View Profile</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  )

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Find Your Therapist</Text>
        <View style={styles.searchContainer}>
          <Ionicons name="search" size={20} color="#6b7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search therapists..."
            placeholderTextColor="#6b7280"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <View style={styles.filterRow}>
          <TouchableOpacity style={styles.filterButton} onPress={() => setFilterModalVisible(true)}>
            <Ionicons name="filter" size={18} color={colors.text} />
            <Text style={styles.filterButtonText}>Filters</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterButton}>
            <Ionicons name="options" size={18} color={colors.text} />
            <Text style={styles.filterButtonText}>Sort</Text>
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={filteredTherapists}
        renderItem={renderTherapistItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ padding: 16 }}
      />

      <FilterModal
        visible={filterModalVisible}
        onClose={() => setFilterModalVisible(false)}
        filters={filters}
        onApplyFilters={(newFilters) => {
          setFilters(newFilters)
          setFilterModalVisible(false)
        }}
      />
    </SafeAreaView>
  )
}

// Sample data for therapists
const therapists = [
  {
    id: 1,
    name: "Dr. Sarah Johnson",
    title: "Licensed Clinical Psychologist",
    specialties: ["Anxiety", "Depression", "Trauma"],
    rating: 4.9,
    reviews: 124,
    location: "Accra, 37 Military Hospital",
    virtual: true,
    inPerson: true,
    image: "/placeholder.svg?height=100&width=100",
    availability: "Next available: Tomorrow",
  },
  {
    id: 2,
    name: "Dr. Michael Chen",
    title: "Licensed Marriage & Family Therapist",
    specialties: ["Relationships", "Couples Therapy", "Family Conflict"],
    rating: 4.8,
    reviews: 98,
    location: "San Francisco, CA",
    virtual: true,
    inPerson: false,
    image: "/placeholder.svg?height=100&width=100",
    availability: "Next available: Thursday",
  },
  {
    id: 3,
    name: "Dr. Amara Patel",
    title: "Clinical Social Worker",
    specialties: ["Depression", "Grief", "Life Transitions"],
    rating: 4.7,
    reviews: 87,
    location: "Chicago, IL",
    virtual: true,
    inPerson: true,
    image: "/placeholder.svg?height=100&width=100",
    availability: "Next available: Today",
  },
  {
    id: 4,
    name: "Dr. James Wilson",
    title: "Licensed Mental Health Counselor",
    specialties: ["Anxiety", "Stress", "Work-Life Balance"],
    rating: 4.6,
    reviews: 76,
    location: "Boston, MA",
    virtual: true,
    inPerson: true,
    image: "/placeholder.svg?height=100&width=100",
    availability: "Next available: Friday",
  },
  {
    id: 5,
    name: "Marian Okyne",
    title: "Psychiatric Nurse Practitioner",
    specialties: ["Medication Management", "Bipolar Disorder", "ADHD"],
    rating: 4.9,
    reviews: 112,
    location: "Korle-Bu, Korle-Bu Teaching Hospital",
    virtual: true,
    inPerson: false,
    image: "/placeholder.svg?height=100&width=100",
    availability: "Next available: Wednesday",
  },
]

