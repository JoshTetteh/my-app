"use client"

import { useState } from "react"
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from "react-native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"
import RadioButton from "./RadioButton"
import CheckBox from "./CheckBox"

interface FilterModalProps {
  visible: boolean
  onClose: () => void
  filters: {
    sessionType: string
    specialty: string
    availability: string[]
    insurance: string[]
  }
  onApplyFilters: (filters: any) => void
}

export default function FilterModal({ visible, onClose, filters, onApplyFilters }: FilterModalProps) {
  const { colors } = useTheme()
  const [localFilters, setLocalFilters] = useState(filters)

  const styles = StyleSheet.create({
    modalContainer: {
      flex: 1,
      backgroundColor: "rgba(0, 0, 0, 0.5)",
      justifyContent: "flex-end",
    },
    modalContent: {
      backgroundColor: colors.background,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      maxHeight: "80%",
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 18,
      fontWeight: "bold",
      color: colors.text,
    },
    closeButton: {
      padding: 4,
    },
    content: {
      padding: 16,
    },
    sectionTitle: {
      fontSize: 16,
      fontWeight: "bold",
      marginBottom: 12,
      color: colors.text,
    },
    section: {
      marginBottom: 24,
    },
    footer: {
      flexDirection: "row",
      padding: 16,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    resetButton: {
      flex: 1,
      paddingVertical: 12,
      alignItems: "center",
      marginRight: 8,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 8,
    },
    resetButtonText: {
      color: colors.text,
      fontWeight: "500",
    },
    applyButton: {
      flex: 1,
      backgroundColor: colors.primary,
      paddingVertical: 12,
      alignItems: "center",
      borderRadius: 8,
    },
    applyButtonText: {
      color: "#ffffff",
      fontWeight: "500",
    },
  })

  const handleReset = () => {
    setLocalFilters({
      sessionType: "all",
      specialty: "all",
      availability: [],
      insurance: [],
    })
  }

  const handleApply = () => {
    onApplyFilters(localFilters)
  }

  const toggleAvailability = (value) => {
    if (localFilters.availability.includes(value)) {
      setLocalFilters({
        ...localFilters,
        availability: localFilters.availability.filter((item) => item !== value),
      })
    } else {
      setLocalFilters({
        ...localFilters,
        availability: [...localFilters.availability, value],
      })
    }
  }

  const toggleInsurance = (value) => {
    if (localFilters.insurance.includes(value)) {
      setLocalFilters({
        ...localFilters,
        insurance: localFilters.insurance.filter((item) => item !== value),
      })
    } else {
      setLocalFilters({
        ...localFilters,
        insurance: [...localFilters.insurance, value],
      })
    }
  }

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Filter Therapists</Text>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <Ionicons name="close" size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          <ScrollView>
            <View style={styles.content}>
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Session Type</Text>
                <RadioButton
                  label="All Session Types"
                  value="all"
                  selected={localFilters.sessionType === "all"}
                  onSelect={() => setLocalFilters({ ...localFilters, sessionType: "all" })}
                />
                <RadioButton
                  label="Virtual Only"
                  value="virtual"
                  selected={localFilters.sessionType === "virtual"}
                  onSelect={() => setLocalFilters({ ...localFilters, sessionType: "virtual" })}
                />
                <RadioButton
                  label="In-Person Only"
                  value="in-person"
                  selected={localFilters.sessionType === "in-person"}
                  onSelect={() => setLocalFilters({ ...localFilters, sessionType: "in-person" })}
                />
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Specialty</Text>
                <RadioButton
                  label="All Specialties"
                  value="all"
                  selected={localFilters.specialty === "all"}
                  onSelect={() => setLocalFilters({ ...localFilters, specialty: "all" })}
                />
                <RadioButton
                  label="Anxiety"
                  value="anxiety"
                  selected={localFilters.specialty === "anxiety"}
                  onSelect={() => setLocalFilters({ ...localFilters, specialty: "anxiety" })}
                />
                <RadioButton
                  label="Depression"
                  value="depression"
                  selected={localFilters.specialty === "depression"}
                  onSelect={() => setLocalFilters({ ...localFilters, specialty: "depression" })}
                />
                <RadioButton
                  label="Trauma"
                  value="trauma"
                  selected={localFilters.specialty === "trauma"}
                  onSelect={() => setLocalFilters({ ...localFilters, specialty: "trauma" })}
                />
                <RadioButton
                  label="Relationships"
                  value="relationships"
                  selected={localFilters.specialty === "relationships"}
                  onSelect={() => setLocalFilters({ ...localFilters, specialty: "relationships" })}
                />
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Availability</Text>
                <CheckBox
                  label="Available Today"
                  checked={localFilters.availability.includes("today")}
                  onToggle={() => toggleAvailability("today")}
                />
                <CheckBox
                  label="Available This Week"
                  checked={localFilters.availability.includes("this-week")}
                  onToggle={() => toggleAvailability("this-week")}
                />
              </View>

              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Insurance</Text>
                <CheckBox
                  label="Blue Cross Blue Shield"
                  checked={localFilters.insurance.includes("blue-cross")}
                  onToggle={() => toggleInsurance("blue-cross")}
                />
                <CheckBox
                  label="Aetna"
                  checked={localFilters.insurance.includes("aetna")}
                  onToggle={() => toggleInsurance("aetna")}
                />
                <CheckBox
                  label="Cigna"
                  checked={localFilters.insurance.includes("cigna")}
                  onToggle={() => toggleInsurance("cigna")}
                />
                <CheckBox
                  label="UnitedHealthcare"
                  checked={localFilters.insurance.includes("united")}
                  onToggle={() => toggleInsurance("united")}
                />
              </View>
            </View>
          </ScrollView>

          <View style={styles.footer}>
            <TouchableOpacity style={styles.resetButton} onPress={handleReset}>
              <Text style={styles.resetButtonText}>Reset</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.applyButton} onPress={handleApply}>
              <Text style={styles.applyButtonText}>Apply Filters</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  )
}

