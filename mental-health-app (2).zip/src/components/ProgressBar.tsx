"use client"
import { View, StyleSheet } from "react-native"
import { useTheme } from "../context/ThemeContext"

interface ProgressBarProps {
  progress: number
}

export default function ProgressBar({ progress }: ProgressBarProps) {
  const { colors } = useTheme()

  const styles = StyleSheet.create({
    container: {
      height: 8,
      backgroundColor: "#e5e7eb", // gray-200
      borderRadius: 4,
      overflow: "hidden",
    },
    progress: {
      height: "100%",
      backgroundColor: colors.primary,
      borderRadius: 4,
    },
  })

  return (
    <View style={styles.container}>
      <View style={[styles.progress, { width: `${progress}%` }]} />
    </View>
  )
}

