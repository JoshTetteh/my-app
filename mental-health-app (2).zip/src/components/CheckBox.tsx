"use client"
import { View, Text, TouchableOpacity, StyleSheet } from "react-native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"

interface CheckBoxProps {
  label: string
  checked: boolean
  onToggle: () => void
}

export default function CheckBox({ label, checked, onToggle }: CheckBoxProps) {
  const { colors } = useTheme()

  const styles = StyleSheet.create({
    container: {
      flexDirection: "row",
      alignItems: "center",
      marginBottom: 12,
    },
    checkbox: {
      height: 20,
      width: 20,
      borderRadius: 4,
      borderWidth: 2,
      borderColor: checked ? colors.primary : "#9ca3af", // gray-400
      alignItems: "center",
      justifyContent: "center",
      marginRight: 12,
      backgroundColor: checked ? colors.primary : "transparent",
    },
    label: {
      fontSize: 16,
      color: colors.text,
    },
  })

  return (
    <TouchableOpacity style={styles.container} onPress={onToggle}>
      <View style={styles.checkbox}>{checked && <Ionicons name="checkmark" size={16} color="#ffffff" />}</View>
      <Text style={styles.label}>{label}</Text>
    </TouchableOpacity>
  )
}

