"use client"

import type React from "react"
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from "react-native"
import { useTheme } from "../context/ThemeContext"
import { Ionicons } from "@expo/vector-icons"

interface Tab {
  key: string
  title: string
  icon: string
}

interface TabViewProps {
  tabs: Tab[]
  activeTab: string
  onTabChange: (tabKey: string) => void
  children: React.ReactNode
}

export default function TabView({ tabs, activeTab, onTabChange, children }: TabViewProps) {
  const { colors } = useTheme()

  const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    tabsContainer: {
      flexDirection: "row",
      backgroundColor: colors.card,
      borderRadius: 8,
      marginHorizontal: 16,
      marginBottom: 16,
    },
    tab: {
      flex: 1,
      paddingVertical: 12,
      alignItems: "center",
      justifyContent: "center",
    },
    activeTab: {
      borderBottomWidth: 2,
      borderBottomColor: colors.primary,
    },
    tabContent: {
      flexDirection: "row",
      alignItems: "center",
    },
    tabIcon: {
      marginRight: 4,
    },
    tabText: {
      fontSize: 14,
      fontWeight: "500",
      color: colors.text,
    },
    activeTabText: {
      color: colors.primary,
    },
    contentContainer: {
      paddingHorizontal: 16,
    },
  })

  return (
    <View style={styles.container}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsContainer}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, activeTab === tab.key && styles.activeTab]}
            onPress={() => onTabChange(tab.key)}
          >
            <View style={styles.tabContent}>
              <Ionicons
                name={tab.icon}
                size={18}
                color={activeTab === tab.key ? colors.primary : colors.text}
                style={styles.tabIcon}
              />
              <Text style={[styles.tabText, activeTab === tab.key && styles.activeTabText]}>{tab.title}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <View style={styles.contentContainer}>{children}</View>
    </View>
  )
}

