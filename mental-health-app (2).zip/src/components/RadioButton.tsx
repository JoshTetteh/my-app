"use client"
import { View, Text, TouchableOpacity, StyleSheet } from "react-native"
import { useTheme } from "../context/ThemeContext"

interface RadioButtonProps {
  label: string
  value: string
  selected: boolean
  onSelect: () => void
}

export default function RadioButton({ label, value, selected, onSelect }: RadioButtonProps) {
  const { colors } = useTheme()

  const styles = StyleSheet.create({
    container: {
      flexDirection: "row",
      alignItems: "center",
      padding: 16,
      borderWidth: 1,
      borderColor: selected ? colors.primary : "#e5e7eb", // gray-200
      borderRadius: 8,
      marginBottom: 12,
      backgroundColor: selected ? "#e6fffa" : colors.card, // teal-50 if selected
    },
    radio: {
      height: 20,
      width: 20,
      borderRadius: 10,
      borderWidth: 2,
      borderColor: selected ? colors.primary : "#9ca3af", // gray-400
      alignItems: "center",
      justifyContent: "center",
      marginRight: 12,
    },
    selected: {
      height: 10,
      width: 10,
      borderRadius: 5,
      backgroundColor: colors.primary,
    },
    label: {
      flex: 1,
      fontSize: 16,
      color: colors.text,
    },
  })

  return (
    <TouchableOpacity style={styles.container} onPress={onSelect}>
      <View style={styles.radio}>{selected && <View style={styles.selected} />}</View>
      <Text style={styles.label}>{label}</Text>
    </TouchableOpacity>
  )
}

