"use client"
import { TextInput, StyleSheet, type ViewStyle } from "react-native"
import { useTheme } from "../context/ThemeContext"

interface TextAreaProps {
  value: string
  onChangeText: (text: string) => void
  placeholder?: string
  style?: ViewStyle
}

export default function TextArea({ value, onChangeText, placeholder, style }: TextAreaProps) {
  const { colors } = useTheme()

  const styles = StyleSheet.create({
    textArea: {
      borderWidth: 1,
      borderColor: "#e5e7eb", // gray-200
      borderRadius: 8,
      padding: 12,
      fontSize: 16,
      color: colors.text,
      textAlignVertical: "top",
      minHeight: 150,
    },
  })

  return (
    <TextInput
      style={[styles.textArea, style]}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor="#9ca3af" // gray-400
      multiline
      numberOfLines={6}
    />
  )
}

