"use client"

import type React from "react"
import { createContext, useState, useContext } from "react"
import { useColorScheme } from "react-native"

type ThemeType = "light" | "dark" | "system"

interface ThemeContextType {
  theme: ThemeType
  setTheme: (theme: ThemeType) => void
  isDark: boolean
  colors: {
    background: string
    text: string
    primary: string
    secondary: string
    card: string
    border: string
    notification: string
  }
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const systemColorScheme = useColorScheme()
  const [theme, setTheme] = useState<ThemeType>("system")

  const isDark = theme === "system" ? systemColorScheme === "dark" : theme === "dark"

  const colors = {
    background: isDark ? "#121212" : "#ffffff",
    text: isDark ? "#ffffff" : "#000000",
    primary: "#0d9488", // teal-600
    secondary: "#14b8a6", // teal-500
    card: isDark ? "#1e1e1e" : "#f9fafb",
    border: isDark ? "#2e2e2e" : "#e5e7eb",
    notification: "#ef4444",
  }

  return <ThemeContext.Provider value={{ theme, setTheme, isDark, colors }}>{children}</ThemeContext.Provider>
}

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}

